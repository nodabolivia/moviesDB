import 'package:flutter/material.dart';
import 'package:flutter_application_movies/models/Movie.dart';
import 'package:flutter_application_movies/pages/detail.dart';

Widget movieItem(Movie movie, BuildContext context) {

    return ListTile(
      title: Text("${movie.title}"),
      subtitle: Text(
          "${movie.voteAverage.toString()} (${movie.voteCount.toString()})"),
      trailing: (movie.posterPath!="")?Image.network("${movie.getImage()}"): Image.asset("assets/noImage.jpg"),
      onTap: () {
        Navigator.pushNamed(context, '/detail', arguments: {'movie': movie});
      },
    );
  
}
