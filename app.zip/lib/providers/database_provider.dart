import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseProvider {
  static Database? _database;
  static final DatabaseProvider db = DatabaseProvider._();

  DatabaseProvider._();

  static Future<Database> get database async {
    if (_database == null) {
      _database = await crearBD();
    }
    return _database!;
  }
  
  static crearBD() async {
    Directory docsDirectory = await getApplicationDocumentsDirectory();
    final path = "${docsDirectory.path}dbmoviesD.db";
    return await openDatabase(
      path,
      version: 1,
      onOpen: (db) {},
      onCreate: (Database db, int version) async {
        await db.execute(
          "CREATE TABLE movies ("
          "id INTEGER PRIMARY KEY,"
          "adult BOOLEAN,"
          "backdropPath TEXT,"
          "genreIds TEXT,"
          "movie_id INTEGER,"
          "originalLanguage TEXT,"
          "originalTitle TEXT,"
          "overview TEXT,"
          "popularity DECIMAL(3,3),"
          "posterPath TEXT,"
          "releaseDate TEXT,"
          "title TEXT,"
          "video BOOLEAN,"
          "voteAverage DECIMAL(3,3)," 
          "voteCount INTEGER"
          ")"
        );
      },
    );
  }
  }



