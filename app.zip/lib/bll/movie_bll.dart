import 'package:flutter_application_movies/models/Movie.dart';

import '../providers/database_provider.dart';

class MovieBLL {
  static Future<List<Movie>> selectAll() async {
    final db = await DatabaseProvider.database;
    final res = await db.rawQuery('SELECT * FROM movies');
    return res.isNotEmpty ? res.map((c) => Movie.fromJson(c)).toList() : [];
  }
}
